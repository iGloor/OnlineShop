﻿namespace OnlineTailoringShop.Models
{
    //linking model
    public class Tailor_Order
    {
        public int TailorID { get; set; }
        public Tailor Tailor { get; set; }
        public int OrderID { get; set; }
        public Order Order { get; set; }
    }
}
