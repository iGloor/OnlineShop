﻿namespace OnlineTailoringShop.Models
{
    //linking model
    public class Order_Product
    {
        public int OrderID { get; set; }
        public Order Order { get; set; }
        public int ProductID { get; set; }
        public Product Product { get; set; }
    }
}
