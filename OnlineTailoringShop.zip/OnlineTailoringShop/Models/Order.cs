﻿using System.ComponentModel.DataAnnotations;

namespace OnlineTailoringShop.Models
{
    public class Order
    {
        [Key]
        public int OrderID { get; set; }
        //Product and tailor ID links?
        public string OrderStatus { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }

        //Relationships
        // An order can have many products
        public List<Product> Products { get; set; }
    }
}
