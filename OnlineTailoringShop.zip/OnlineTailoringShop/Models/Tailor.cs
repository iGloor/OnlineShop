﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineTailoringShop.Models
{
    public class Tailor: Person
    {
        [Key]
        public int TailorID { get; set; }

        [ForeignKey("PersonID")]

        //ProfilePicture URL? 
        public string WorkExperience { get; set; }
        public string Skills { get; set; }
        //Reviews from customers
        public decimal ReviewRatings { get; set; }
        public string ReviewDescriptions { get; set; }
        public decimal Income { get; set; }

        //Relationships
        // A tailor can have many orders
        public List<Order> Orders { get; set; }

    }
}
