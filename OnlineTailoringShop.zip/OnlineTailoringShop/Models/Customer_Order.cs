﻿namespace OnlineTailoringShop.Models
{
    public class Customer_Order
    {
        public int CustomerID { get; set; }
        public Customer Customer { get; set; }

        public int OrderID { get; set; }
        public Order Order { get; set; }
    }
}
