﻿using System.ComponentModel.DataAnnotations;

namespace OnlineTailoringShop.Models
{
    public class Product
    {
        [Key]
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public int FabricID { get; set; }
        public string FabricName { get; set; }
        public int ColourID { get; set; }
        public string ColourName { get; set; }
    }
}
