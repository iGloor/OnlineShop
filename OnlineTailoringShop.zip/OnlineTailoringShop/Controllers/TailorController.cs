﻿using Microsoft.AspNetCore.Mvc;
using OnlineTailoringShop.Data;

namespace OnlineTailoringShop.Controllers
{
    public class TailorController
    {
        private readonly ApplicationDbContext _context;
        public TailorController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var data = _context.Tailors.ToList();
            return View();
        }
    }
}
