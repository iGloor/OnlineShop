﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using OnlineTailoringShop.Models;

namespace OnlineTailoringShop.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        //Idk what this is for? From video 13

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Customer_Order>().HasKey(co => new
            {
                co.CustomerID,
                co.OrderID
            });
            //builder.Entity<Customer_Order>().HasOne(c => c.Customer).WithMany(co => co.Customer_Order).HasForeignKey(c => c.CustomerID);
            //builder.Entity<Customer_Order>().HasOne(c => c.Order).WithMany(co => co.Customer_Order).HasForeignKey(c => c.OrderID);
            base.OnModelCreating(builder);
        }
     
        public DbSet<Customer_Order> CustomerOrders { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
    }
}